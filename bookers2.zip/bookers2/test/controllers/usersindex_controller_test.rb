require 'test_helper'

class UsersindexControllerTest < ActionDispatch::IntegrationTest
  test "should get show" do
    get usersindex_show_url
    assert_response :success
  end

  test "should get edit" do
    get usersindex_edit_url
    assert_response :success
  end

end
