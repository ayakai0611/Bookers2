# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '026353055bf7e0d1c02de5f64df0d65a3e87550c9b36b14e4cfe3d0e75fb492f35d77c48b875c21a8309308b493b5cf755f5cae42b4168b077b51e1bd9a1f978'